
<template>
<div class="container">
    <div class="row">
    
    <div class="col-md-1" :style="{lineHeight:'45px',fontWeight:'600',marginTop:'10px'}">方向：</div>
    <div :class="['col-md-1',direIndex==item.id?'act':'']" 
         @click="changedireTab(item.id)"
         :style="{lineHeight:'45px',textAlign:'center',marginTop:'10px',cursor:'pointer'}" 
         v-for="(item,index) in direData" 
         :key="'dire'+index" >{{item.name}}</div>

    <div class="col-md-1" :style="{lineHeight:'45px',fontWeight:'600',marginTop:'10px'}">分类：</div>
    <div :class="['col-md-1',ClassIndex==item.id?'act':'','tabLabel']" 
         @click="changeclassTab(item.id)"
         :style="{lineHeight:'45px',textAlign:'center',marginTop:'10px',cursor:'pointer'}"  
         v-for="(item,index) in classData" 
         :key="'class'+index" >{{item.name}}</div>

    </div>
</div>

</template>
<script >
import axios from 'axios';
export default {
  
    data(){
      return{
          direData:[],
          classData:[],
          direIndex:'0',
          ClassIndex:'0'
         
      }
    },
    mounted(){
        this.getlabel()
    },
    methods:{
      getlabel(){
        axios.get('http://5b076a5892b3b4001425a067.mockapi.io/api/banner/produce').then((res) => {
            if(res.status==200&&res.data&&res.data.length>0){
                console.log(res.data[0].classData)
                this.direData=res.data[0].direData;
                this.classData=res.data[0].classData;
            }
            console.log(res)
                })
      },
      changedireTab(id){
          this.direIndex=id
      },
      changeclassTab(id){
          this.ClassIndex=id
      }
     
    }

}
</script>
<style scoped>
 .act{background:#000;color:#fff;border-radius:3px};
  .tabLabel{
      color:#f00
  }
</style>

