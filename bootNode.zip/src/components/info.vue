<template>
  <div class="container my_p" style="background:#fff;margin-top:30px">
     <div class="blog-title"><h1>Introducing Printable Award Certificates</h1></div>
     <p>In the recent years loads of designers, developers and digital agencies have been requesting Award Certificates to print for their office walls. I’m stoked to announce they are finally here!</p>
     <p>Traditional certificate designs are bland but I wanted something fresh, colorful and eye-catching (on the wall). After seeing recent illustration work by fellow South African <a href="https://dribbble.com/jasondevilliers" target="_blank">Jason De Villiers</a>, I knew he’d be the guy to help with a unique art direction.</p>
     <p>I’m super stoked with the outcome and also announced it on Dribbble as the debut One Page Love shot (update: no longer using Dribbble).</p>
     <p>Another added touch we’re looking into is foil stamping the gold star or printing it as a glossy sticker to layer on top of the print. We just need to experiment a bit more there on what works best. </p>
     <p>In the recent years loads of designers, developers and digital agencies have been requesting Award Certificates to print for their office walls. I’m stoked to announce they are finally here!</p>
     <p>Traditional certificate designs are bland but I wanted something fresh, colorful and eye-catching (on the wall). After seeing recent illustration work by fellow South African <a href="https://dribbble.com/jasondevilliers" target="_blank">Jason De Villiers</a>, I knew he’d be the guy to help with a unique art direction.</p>
     <p>I’m super stoked with the outcome and also announced it on Dribbble as the debut One Page Love shot (update: no longer using Dribbble).</p>
     <p>Another added touch we’re looking into is foil stamping the gold star or printing it as a glossy sticker to layer on top of the print. We just need to experiment a bit more there on what works best. </p>
     <p>In the recent years loads of designers, developers and digital agencies have been requesting Award Certificates to print for their office walls. I’m stoked to announce they are finally here!</p>
     <p>Traditional certificate designs are bland but I wanted something fresh, colorful and eye-catching (on the wall). After seeing recent illustration work by fellow South African <a href="https://dribbble.com/jasondevilliers" target="_blank">Jason De Villiers</a>, I knew he’d be the guy to help with a unique art direction.</p>
     <p>I’m super stoked with the outcome and also announced it on Dribbble as the debut One Page Love shot (update: no longer using Dribbble).</p>
     <p>Another added touch we’re looking into is foil stamping the gold star or printing it as a glossy sticker to layer on top of the print. We just need to experiment a bit more there on what works best. </p>
     <p>In the recent years loads of designers, developers and digital agencies have been requesting Award Certificates to print for their office walls. I’m stoked to announce they are finally here!</p>
     <p>Traditional certificate designs are bland but I wanted something fresh, colorful and eye-catching (on the wall). After seeing recent illustration work by fellow South African <a href="https://dribbble.com/jasondevilliers" target="_blank">Jason De Villiers</a>, I knew he’d be the guy to help with a unique art direction.</p>
     <p>I’m super stoked with the outcome and also announced it on Dribbble as the debut One Page Love shot (update: no longer using Dribbble).</p>
     <p>Another added touch we’re looking into is foil stamping the gold star or printing it as a glossy sticker to layer on top of the print. We just need to experiment a bit more there on what works best. </p>
  </div>
</template>
<script >
export default {
  
}
</script>
<style scoped>
.blog-title h1 {
    font-family: Quicksand,Arial Rounded MT Bold,Helvetica Rounded,Arial,sans-serif;
    color: #222;
    text-align: center;
    text-transform: none;
    letter-spacing: -0.125rem;
    font-weight: bold;
    font-size: 3rem;
    line-height: 5rem;
    text-transform: uppercase;
    letter-spacing: 0.125rem;
    margin-bottom: 2.5rem;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding-right: 5rem;
    padding-left: 5rem;
    display: block;
}

.my_p p{
  padding-left: 10rem;
    padding-right: 10rem;
    font-family: -apple-system,BlinkMacSystemFont,Arial,Helvetica Neue,Helvetica,sans-serif;
    font-size: 1.25rem;
    line-height: 1.75rem;
    margin: 0 0 1.25rem 0;
    padding: 0;
    color: #666;
      margin: 0 0 0.9375rem 0;
}
</style>

