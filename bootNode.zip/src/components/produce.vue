<template>
  <div>
      <select-label></select-label>
      <div class="container">
          <div class="archive-header-info">
                <div class="archive-title">
                    <span class="grey-shadow">
                        <h1>You are browsing 323  One Page Templates</h1>
                    </span>
                </div>
                <div class="archive-description">
                    <span class="grey-shadow">
                        One Page website templates and themes to help you kickstart your next project. Use the top menu to browse template sub-categories.See our 
                        <a href="https://onepagelove.com/go/bluehost">January $2.95 Hosting Special</a> 🎉 
                    </span>
                </div>
            </div>
            
            <div class="row" style="margin-top:20px;">
                <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro01.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
                 <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro02.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
                 <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro03.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
                 <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro04.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
                 <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro05.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
                 <div class="col-xs-6 col-md-4">
                    <div class="thumbnail">
                        <img src="../assets/pro06.jpg" alt="...">
                        <div class="caption">
                            <h4>PB Law HTML Template</h4>
                            <p>Templates</p>
                        </div>
                    </div>
                </div>
            </div>
      </div>

            <nav aria-label="Page navigation ">
                <ul class="pagination pagination-lg navbar-right">
                    <li>
                    <a href="#" aria-label="Previous" style="margin-right:10px">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                    </li>
                    <li class="active"><a style="margin-right:10px" href="#">1</a></li>
                    <li><a style="margin-right:10px" href="#">2</a></li>
                    <li><a style="margin-right:10px" href="#">3</a></li>
                    <li><a style="margin-right:10px" href="#">4</a></li>
                    <li><a style="margin-right:10px" href="#">5</a></li>
                    <li>
                    <a href="#" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                    </li>
                </ul>
            </nav>
            
        <div class="container " id="footer-container">
            <div id="footer-newsletter">
                <div class="newsletter-title">Join the One Page Love Newsletter and get a free eBook!</div>
                <div class="newsletter-pitch">
                    <ul>
                    <li><span class="tick ft">✓</span> Monthly</li>
                    <li><span class="tick">✓</span> Inspiration</li>
                    <li><span class="tick">✓</span> Freebies</li>
                    <li><span class="tick">✓</span> Resources</li>
                    <li><span class="tick">✓</span> Free eBook</li>				
                    </ul>
                </div>
                <div class="newsletter-lower-wrapper">
                    <div class="newsletter-ebook">
                    <img src="https://onepagelove-wpengine.netdna-ssl.com/wp-content/themes/onepagelove/img/footer-ebook.jpg" alt="10 Quick Tips to tighten your Landing Page design" width="500" height="375">
                    </div>
                </div>
            </div>
        </div>
        
  </div>
</template>

<script >
import selectLabel from './select_label'
export default { 
      components: {
        selectLabel
    },
}
</script>
<style scoped>
@media (max-width: 840px){ 
.archive-header-info .archive-title,.archive-header-info .archive-description {
    max-width: none;
}
}
.archive-header-info .archive-title {
    font-size: 2.625rem;
    line-height: 2.625rem;
    margin-bottom: .625rem;
    letter-spacing: -2px;
    max-width: 80%;
    margin-right: auto;
    margin-left: auto;
}
.archive-header-info .archive-title {

    font-size: 2.625rem;
    line-height: 2.625rem;
    margin-bottom: .625rem;
    letter-spacing: -2px;
    max-width: 80%;
    margin-right: auto;
    margin-left: auto;
}
.archive-header-info .archive-title h1{
    text-align:center;
}
@media (max-width: 1430px){
.archive-header-info .archive-description {
    max-width: 80%;
}
}
 .archive-header-info .archive-description {
    font-family: -apple-system,BlinkMacSystemFont,Arial,Helvetica Neue,Helvetica,sans-serif;
    color: #777;
    max-width: 60%;
    margin-right: auto;
    margin-left: auto;
    font-size: 1.25rem;
    line-height: 1.5rem;
    letter-spacing: -0.2px;
}

#container-outer #footer-container {
    position: relative;
}
#footer-container {
    z-index: 2000;
}
#footer-container {
    background: #141414;
}
.newsletter-title {
   text-align: center;
    color: #DDD;
    max-width: 90%;
    margin: 0 auto 1.25rem auto;
    font-size: 2.56rem;
    line-height: 2rem;
    font-family: Quicksand,Arial Rounded MT Bold,Helvetica Rounded,Arial,sans-serif;
    font-weight: bold;
    letter-spacing: -1px;
    margin-top: 90px;
}
.newsletter-pitch {
        text-align: center;
    color: #AAA;
    max-width: 90%;
    margin: 0 auto 2.5rem auto;
    font-family: -apple-system,BlinkMacSystemFont,Arial,Helvetica Neue,Helvetica,sans-serif;
    font-size: 1.65rem;
    line-height: 1.75rem;
    padding: 0;
}
.newsletter-pitch ul {
    margin: 0;
    padding: 0;
    list-style: none;
}
.newsletter-pitch ul li {
    display: inline-block;
    list-style: none;
}
.newsletter-pitch .tick {
    color: #FD6CA3;
    margin-left: .625rem;
    margin-right: -0.125rem;
}
.newsletter-lower-wrapper .newsletter-ebook {
    clear: both;
    display: block;
    padding-top: 2.5rem;
    text-align: center;
    max-width: 90%;
    margin: 0 auto 0 auto;
}

</style>
